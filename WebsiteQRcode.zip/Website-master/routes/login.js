var express = require('express');
var router = express.Router();
var fs = require('fs');

router.get('/:conversationId', function(req, res){

	// var jsonName = './temp.txt';
	var w_data = new Buffer(req.params.conversationId);
	fs.writeFile(__dirname + '/temp.txt', w_data, {flag: 'a'}, function (err) {
   		if(err) {
    		console.error(err);
    	} else {
       		console.log('写入成功');
    	}
});

	console.log(req.params.conversationId);
});

module.exports = router;

