var express = require('express');
var router = express.Router();
var fs = require('fs');

router.get('/:conversationId', function(req, res){
	// console.log('qweasdfdasf');
	fs.readFile(__dirname + '/temp.txt', {flag: 'r+', encoding: 'utf8'}, function (err, data) {
    	if(err) {
     		console.error(err);
     		return;
    	}
    	console.log(data);
    	if (req.params.conversationId == data) {
    		console.log('成功');
    		res.render('realhome');
    	} else {
    		console.log('未扫描成功成功');
    	}
	});
});

module.exports = router;

